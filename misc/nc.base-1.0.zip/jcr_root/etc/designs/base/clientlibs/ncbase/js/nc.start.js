var NC = {
  modules: {},
  components: {},
  componentsSet: [],
  state: {}
};
