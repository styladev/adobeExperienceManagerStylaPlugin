NC = window.NC || {
  components: {},
  modules: {},
  state: {}
};

NC.components.cookieNote = {
  init: function () {
    this.options = window.deepmerge({}, this.config);
    this.initPlugin();
  },

  encodeStr: function (str) {
    const revertAmp = str.replace(/&amp;/g, '&');
    const txt = document.createElement('textarea');
    txt.innerHTML = revertAmp;

    return txt.value;
  },

  addExtension: function (url) {
    const urlArr = url.split('.');

    if (!url) {
      return '';
    }

    if (urlArr[urlArr.length - 1] === 'html') {
      return url;
    } else {
      return url + '.html';
    }
  },

  getLinkConfig: function (_href, _link) {
    const href = this.addExtension(_href);
    const link = href ? _link : '';
    const linkElement = link ? '<a aria-label="learn more about cookies" tabindex="0" class="cc-link" href="{{href}}" target="_blank">{{link}}</a>' : '';

    return {
      href: href,
      link: link,
      linkElement: linkElement
    }
  },

  initPlugin: function () {
    const _this = this;
    const message = this.encodeStr(_this.options.message);
    const linkConfig = this.getLinkConfig(this.options.href, this.options.link);
    const href = linkConfig.href;
    const link = linkConfig.link;
    const linkElement = linkConfig.linkElement;

    if (!_this.options.message) {
      return;
    }

    window.cookieconsent.initialise({
      content: {
        message: message, // Disclaimer Text *
        dismiss: _this.options.dismiss, // Dismiss button label
        allow: _this.options.allow, // Allow button label
        deny: _this.options.deny, // Deny button label
        link: link, // Policy Link Text
        href: href, // Policy Link Path
        target: '_blank'
      },
      elements: {
        message: '<div id="cookieconsent:desc" class="cc-message">{{message}}</div>',
        messagelink: '<div id="cookieconsent:desc" class="cc-message">{{message}} ' + linkElement + '</div>',
      },
      compliance: {
        'info': '<div class="cc-compliance">{{dismiss}}</div>',
        'opt-in': '<div class="cc-compliance cc-highlight">{{deny}}{{allow}}</div>',
        'opt-out': '<div class="cc-compliance cc-highlight">{{deny}}{{dismiss}}</div>',
      },
      window: '<div role="dialog" aria-label="cookieconsent" aria-describedby="cookieconsent:desc" class="cookienote__banner cc-window {{classes}}"><div class="cookienote__inner">{{children}}</div></div>',
      type: _this.options.type, // opt-in, opt-out, info, none
      layout: _this.options.layout || 'bottom', // top, bottom, left, right
      revokable: false, // we be managed by SWITCH component
      onStatusChange: function (status) {
        const type = _this.options.type || 'none';

        if ((type === 'opt-in' && status === 'allow')
        || type === 'opt-out' && status === 'deny') {
          location.reload(true);
        }
      }
    });
  }
};

NC.modules.componentLoader.register(NC.components.cookieNote, 'CookieNote');
