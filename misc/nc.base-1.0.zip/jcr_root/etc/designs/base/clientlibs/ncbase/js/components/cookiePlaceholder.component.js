NC = window.NC || {
  components: {},
  modules: {},
  state: {}
};

NC.components.cookiePlaceholder = {
  init: function () {
    this.options = window.deepmerge({}, this.config);
    this.setRefs();

    if (!this.isValid) {
      return;
    }

    this.renderLoader();
    if (!this.condition) {
      this.renderPlaceholders();
    }
    this.removeLoader();
  },

  setRefs: function () {
    this.condition = NC.state.isCookiesAccepted;
    this.placeholder = this.el.querySelector('.cookieplaceholder__base');
    this.placeholderTarget = document.querySelectorAll('.cookieplaceholder__target');
    this.isValid = this.placeholder && this.placeholderTarget && this.placeholderTarget.length > 0;
  },

  renderLoader: function () {
    for (let i = 0; i < this.placeholderTarget.length; i += 1) {
      this.placeholderTarget[i].classList.add('cookieplaceholder__target--isLoading');
    }
  },

  removeLoader: function () {
    for (let i = 0; i < this.placeholderTarget.length; i += 1) {
      this.placeholderTarget[i].classList.remove('cookieplaceholder__target--isLoading');
    }
  },

  renderPlaceholders: function () {
    for (let i = 0; i < this.placeholderTarget.length; i += 1) {
      const clone = this.placeholder.cloneNode(true);
      this.placeholderTarget[i].innerHTML = '';
      this.placeholderTarget[i].appendChild(clone);
    }
  }
};

NC.modules.componentLoader.register(NC.components.cookiePlaceholder, 'CookiePlaceholder');
