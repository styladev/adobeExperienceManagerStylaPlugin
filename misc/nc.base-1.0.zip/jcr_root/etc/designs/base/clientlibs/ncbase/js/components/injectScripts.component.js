NC = window.NC || {
  components: {},
  state: {}
};

NC.components.injectScripts = {
  init: function () {
    this.options = window.deepmerge({}, this.config);
    this.setRefs();
    this.setEventListeners();
  },

  setEventListeners: function () {
    if (this.condition) {
      if (this.options.src) {
        this.insertScriptTag(this.scriptParams);
      }

      if (this.options.isTemplate && !this.options.src) {
        this.insertScriptTemplate(this.$template);
      }
    }
  },

  setRefs: function () {
    const _this = this;

    this.scriptParams = {
      src: _this.options.src,
      position: _this.options.position,
      id: _this.options.id,
      isTemplate: _this.options.isTemplate
    };
    this.eventName = this.options.event || 'script.injected';
    this.dependencySelector = this.options.dependencySelector;

    const isElementPresent = this.options.selector ? this.isElementPresent(this.options.selector) : true;
    this.condition = isElementPresent && NC.state.isCookiesAccepted;
    this.$template = this.el.querySelector('script[type="text/template"]');
  },

  insertScriptTag: function (params) {
    const position = params.position || 'any';
    const _this = this;

    if (!params.src) {
      return;
    }

    const $script = document.createElement('script');
    $script.async = true;
    $script.onload = function () {
      const event = new Event(_this.eventName);
      document.dispatchEvent(event);
    };

    if (position === 'first') {
      const $firstScript = document.getElementsByTagName('script')[0] || null;
      $firstScript.parentNode.insertBefore($script, $firstScript);
    } else if (position === 'last') {
      document.body.appendChild($script);
    } else {
      document.head.appendChild($script);
    }

    $script.src = params.src;
  },

  insertScriptTemplate: function ($template) {
    if (!$template) {
      return;
    }

    const $script = document.createElement('script');

    for (var i = 0; i < $template.attributes.length; i++) {
        var a = $template.attributes[i];
        if (a.name !== 'type') {
          $script.setAttribute(a.name, a.value);
        }
    }

    $script.innerHTML = $template.innerHTML;
    this.el.appendChild($script);
  },

  isElementPresent: function (selector) {
    return document.querySelector(selector);
  }
};

NC.modules.componentLoader.register(NC.components.injectScripts, 'InjectScripts');
