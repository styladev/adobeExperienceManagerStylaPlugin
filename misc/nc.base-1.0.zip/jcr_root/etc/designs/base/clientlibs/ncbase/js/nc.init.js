NC = window.NC || {
  modules: {},
  state: {}
};

NC.state = NC.modules.state.setState();
NC.modules.logger.log('NC.state: ', NC.state);

document.addEventListener('DOMContentLoaded', function() {
  NC.modules.componentLoader.init();
});
