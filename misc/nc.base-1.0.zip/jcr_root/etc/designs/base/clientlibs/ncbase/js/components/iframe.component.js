NC = window.NC || {
  components: {},
  state: {}
};

NC.components.iframe = {
  init: function () {
    this.options = window.deepmerge({}, this.config);
    this.setRefs();
    this.setEventListeners();
  },

  setEventListeners: function () {
    if (this.condition) {
      if (this.options.src) {
        this.renderIframe(this.options.src, this.options.id);
        if (this.options.js) {
          this.insertScriptTemplate();
        }
      }
    }
  },

  setRefs: function () {
    this.condition = NC.state.isCookiesAccepted;
  },

  renderIframe: function (src, id) {
    if (!src) {
      return;
    }

    this.el.classList.add('iframe--isLoading');

    const _this = this;
    const $iframe = document.createElement('iframe');

    $iframe.onload = function() {
      _this.el.classList.remove('iframe--isLoading');
    };
    $iframe.onerror = function() {
      _this.el.classList.remove('iframe--isLoading');
    };
    $iframe.src = src + '?isiframe=true';
    $iframe.setAttribute('allow', 'geolocation; microphone; camera');
    $iframe.className = 'iframe__frame';
    if (id) {
      $iframe.setAttribute('id', id);
    }

    const attr = this.options.attr;

    if (attr) {
      for (var key in attr) {
          if (attr.hasOwnProperty(key)) {
              $iframe.setAttribute(key, attr[key]);
          }
      }
    }

    this.el.appendChild($iframe);
  },

  insertScriptTemplate: function () {
    const $script = document.createElement('script');
    const $template = this.el.querySelector('script[type="text/template"]');
    $script.innerHTML = $template.innerHTML;
    this.el.appendChild($script);
  }
};

NC.modules.componentLoader.register(NC.components.iframe, 'Iframe');
