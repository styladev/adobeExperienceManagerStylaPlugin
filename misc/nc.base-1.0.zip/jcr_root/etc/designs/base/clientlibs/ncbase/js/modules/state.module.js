NC = window.NC || {
  modules: {
    cookie: {}
  }
};

NC.modules.state = {
  getCookieMode: function () {
    const cookieNoteEl = document.querySelector('.cookienote__base');
    return cookieNoteEl ? cookieNoteEl.dataset.mode || 'info' : 'none';
  },

  isCookiesAccepted: function (cookieMode) {
    const cookieValue = NC.modules.cookie.getCookie('cookieconsent_status');

    if (cookieValue === 'deny' || (cookieMode === 'opt-in' && !cookieValue)) {
        return false;
    }

    return true;
  },

  setState: function () {
    const cookieMode = this.getCookieMode();
    const isCookiesAccepted = this.isCookiesAccepted(cookieMode);

    return {
      cookieMode: cookieMode,
      isCookiesAccepted: isCookiesAccepted
    }
  }
};
