NC = window.NC || {
  components: {},
  state: {}
};

NC.components.googleAnalytics = {
  init: function () {
    this.options = window.deepmerge({}, this.config);
    this.setGoogleAnalyticsObject(this.options.gaId);
  },

  setGoogleAnalyticsObject: function (gaId) {
    window.GoogleAnalyticsObject = 'ga';
    // The queued commands will be executed once analytics.js loads.
    window.ga = window.ga || function () {
      (ga.q = ga.q || []).push(arguments);
    };

    ga.l = +new Date;
    ga('create', gaId, 'auto');
    ga('send', 'pageview');
  },
};

NC.modules.componentLoader.register(NC.components.googleAnalytics, 'GoogleAnalytics');
