NC = window.NC || {
  components: {},
  state: {}
};

NC.components.html = {
  init: function () {
    this.options = window.deepmerge({}, this.config);
    this.setRefs();
    this.setEventListeners();
  },

  setEventListeners: function () {
    if (this.condition) {
      this.insertHtml(this.$template);
    }
  },

  setRefs: function () {
    this.$template = this.el.querySelector('script.template');
    this.$contentEncoded = this.$template ? this.encodeStr(this.$template.innerHTML) : '';
    this.condition = this.$template && (this.isContentSafe(this.$contentEncoded) || NC.state.isCookiesAccepted);
  },

  insertHtml: function () {
    const $wrapper = document.createElement('div');
    $wrapper.innerHTML = this.$contentEncoded;
    this.el.appendChild($wrapper);

    // execute all scripts
    this.replaceNode($wrapper);
  },
  
  isContentSafe: function ($content) {
    const isScript = /<script[\s\S]*?>[\s\S]*?<\/script>/gi;
    const isFrame = /<iframe[\s\S]*?>[\s\S]*?<\/iframe>/gi;
    return !$content.match(isScript) && !$content.match(isFrame);
  },

  replaceNode: function(node) {
    const _this = this;

    if (this.isDynamicTag(node) === true) {
      node.parentNode.replaceChild(_this.cloneNode(node), node);
    } else {
      var i = 0,
        children = node.childNodes;

      while (i < children.length ) {
        this.replaceNode(children[i++]);
      }
    }

    return node;
  },

  isDynamicTag: function (node) {
    return node.tagName === 'SCRIPT' || node.tagName === 'IFRAME';
  },

  cloneNode: function (node){
    const $script = document.createElement(node.tagName);
    $script.text = node.innerHTML;
    for(var i = node.attributes.length-1; i >= 0; i--) {
      $script.setAttribute(node.attributes[i].name, node.attributes[i].value);
    }
    return $script;
  },

  encodeStr: function (str) {
    const revertAmp = str.replace(/&amp;/g, '&');
    const txt = document.createElement('textarea');
    txt.innerHTML = revertAmp;

    return txt.value;
  }
};

NC.modules.componentLoader.register(NC.components.html, 'Html');
