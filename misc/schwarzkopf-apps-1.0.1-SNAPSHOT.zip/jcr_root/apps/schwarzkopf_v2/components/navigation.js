"use strict";

use(function () {

    var path = this.childNode.path;
    var page = pageManager.getContainingPage(path);
    var template = page.properties.get("cq:template", "");
    var templateName = /[^/]*$/.exec(page.properties.get("cq:template", ""))[0];
    var currentPageTemplateName = /[^/]*$/.exec(currentPage.properties.get("cq:template", ""))[0];
    var display = !page.properties.get("hideInNav") && (template.endsWith("/overview") || template.endsWith("/category") || template.endsWith("/brands") || template.endsWith("/topic") || template.endsWith("/redirect"));
    var href = resource.resourceResolver.map(page.getPath());
    var name = page.getName();
    var title = page.getTitle();
    var displayTitle = page.getNavigationTitle() || title || name;
    var hideSubnavigation = page.properties.get("hideSubnavigation", "false");

    var isChildPage = function() {
        return currentPage.getPath().startsWith(page.getPath());
    };

    return {
        display: display,
        hideSubnavigation: hideSubnavigation,
        page: page,
        href: href,
        name: name,
        template: template,
        templateName: templateName,
        currentPageTemplateName: currentPageTemplateName,
        title: title,
        displayTitle: displayTitle,
        isChildPage: isChildPage
    };

});

