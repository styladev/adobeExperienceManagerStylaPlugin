use(function() {

  'use strict';

  var embedCode = this.embedCode;

  var videoIdFromEmbedCode = function () {
    var regexResult = /youtube\.com\/embed\/([A-Za-z0-9\-\_]*)/.exec(embedCode);
    return regexResult[1];
  }

  return {
    videoIdFromEmbedCode: videoIdFromEmbedCode()
  };
});
