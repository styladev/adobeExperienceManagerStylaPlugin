'use strict';

use(function () {

    var mappedPath = resource.resourceResolver.map(currentPage.path);
    var name = currentPage.getName();
    var title = currentPage.getTitle();
    var displayTitle = currentPage.getNavigationTitle() || title || name;

    return {
        mappedPath: mappedPath,
        name: name,
        title: title,
        displayTitle: displayTitle,
    };

});
