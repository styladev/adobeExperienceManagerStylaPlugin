
const accountToggle = $('.article-inline'); //should be changed to icon in menu
const accountToggleSlider = $('.slider-item .premium-article');
const accountLayer = $('.account');

const accountClose = $('.account-close');
const accountLogout = $('.logout-account');
const accountLogoutClose = $('.logout-close');
const accountSignin = $('.account-inner--signin');
const accountSignup = $('.account-inner--signup');
const accountSignupconfirm = $('.account-inner--signupconfirm');
const signinLink = $('.signin-link');
const signupLink = $('.signup-link');
const accountToggleFormSignin = $('.account-toggle-signin');
const accountToggleFormSignup = $('.account-toggle-signup');
const accountToggleFormConfirm = $('.account-toggle-confirm');
const accountPassword = $('#password');
const accountPasswordConfirm = $('#confirm_password');
const accountIcon = $('.account-icon');
//const accountIconActive = $('.account-icon--active');
//const accountIconInactive = $('.account-icon--inactive');
const accountIconLabel = $('.account-icon .account-icon--label');
const accountIconSvg = $('.account-icon a .svg-icon');
const articlePremium = $('.page.premium-article');
const articlePremiumLayer = $('.premium-layer');
const accountPasswordReset = $('.account__form-account--pwconfirm');
const accountPasswordResetEmail = $('.account__form-account--pwconfirm #email');
const body = $('body');

const accountForm = $('#signupForm');
const accountFormSignupArticle = $('#signupForm-article');
const accountFormSignin = $('#signinForm');
const accountFormSigninArticle = $('#signinForm-article');
//const accountFormDetails = $('.account__form-signup');
const accountConfirmLogout = $('#logoutConfirm');

const systemMessage = $('.system-message');
const systemLoader = $('.system-loader');


var crm_cookie = getCookie("ecrm_login_token");

//for each for accountToggle get id's for redirection 
accountToggle.each( function() {
	var id = $(this).attr('data-id'); 
	$('#' + id ).on('click', function (e) {
		e.preventDefault();  
		e.stopPropagation();
		var premiumArticlePath = $(this).attr('data-url');
		// var crm_cookie = getCookie("ecrm_login_token");
		// if (crm_cookie) { 
		window.location.href = premiumArticlePath + ".html";
		// }
	});
});


accountToggleSlider.each( function() {
	var id = $(this).attr('data-id'); 
	$('#' + id ).on('click', function (e) {
		e.preventDefault();  
		e.stopPropagation(); 
		var crm_cookie = getCookie("ecrm_login_token");
		// if (crm_cookie) { 
		window.location.href = $(this).attr('data-url');
		// } else {
		// toggleAccount();
		// } 
	});
});


accountIcon.on('click', function(e) {
	if($('.account-icon').hasClass('account-icon--active')) {
		window.location.href = accountIcon.attr('data-url');
	} else {
		toggleAccount();
	}
});


accountClose.on('click', function (e) {
	e.preventDefault();
	e.stopPropagation();
	closeLayover();
});

//Sign up - Layover
accountForm.on('submit', function(e) {

	systemShowLoader( $('#signupForm .system-loader') );
	$('#signupForm .account-submit').prop("disabled", true);
	//var path = $('#signupForm input[name=premium-article-path-signup]').val();
	var email = $('#signupForm input[name=email_signup]').val();
	var password = $('#signupForm input[name=password_signup]').val();
	var newsletter = $('#signupForm input[name=newsletter]').prop("checked");
	var terms = $('#signupForm input[name=terms]').prop("checked");
	var policy = $('#signupForm input[name=privacypolicy]').prop("checked");
	var redirectlink = window.location.href;
	var partner = getQueryVariable('partner');
	//Use JQuery AJAX request to post data to a Sling Servlet
	$.ajax({
		    type: "POST",
		    url: "/bin/schwarzkopf/ecrm/signup",
		    data: {  email: email, password: password, newsletter: newsletter, terms: terms, privacypolicy: policy , redirectlink:redirectlink, partner:partner },
		    success: function(data) {
			        if (data.showLogin=="true") {
				        // data.redirect contains the string URL to redirect to
				toggleAccountForm('signin');
				systemHideLoader();
				systemShowMessage(data.textStatus, 'green', $('#signinForm .system-message') );
				    

			} else {
				// alert(data.textStatus);
				systemHideLoader();
				systemShowMessage(data.textStatus, 'red', $('#signupForm .system-message') );
				$('#signupForm .account-submit').prop("disabled", false);
				    }
			    }
	});

	e.preventDefault();
	e.stopPropagation();
});


//Sign up - Article Page   
accountFormSignupArticle.on('submit', function(e) {

	systemShowLoader( $('#signupForm-article .system-loader') );
	$('#signupForm-article .account-submit').prop("disabled", true);
	var email = $('#signupForm-article input[name=email_signup-article]').val();
	var password = $('#signupForm-article input[name=password_signup-article]').val();
	var newsletter = $('#signupForm-article input[name=newsletter-article]').prop("checked");
	var terms = $('#signupForm-article input[name=termsandconditions-article]').prop("checked");
	var policy = $('#signupForm-article input[name=privacypolicy-article]').prop("checked");
	var redirectlink = window.location.href;
	var partner = getQueryVariable('partner');
	//Use JQuery AJAX request to post data to a Sling Servlet
	$.ajax({
		    type: "POST",
		    url: "/bin/schwarzkopf/ecrm/signup",
		    data: { email: email, password: password, newsletter: newsletter, terms: terms, privacypolicy: policy ,redirectlink:redirectlink, partner:partner},
		    success: function(data) {
			        if (data.showLogin=="true") {
				toggleAccountForm('signin');
				systemHideLoader();
				systemShowMessage(data.textStatus, 'green', $('#signinForm-article .system-message') );
			} else {
				// alert(data.textStatus);
				systemHideLoader();
				systemShowMessage(data.textStatus, 'red', $('#signupForm-article .system-message') );
				$('#signupForm-article .account-submit').prop("disabled", false);
				    }
			    }
	});

	e.preventDefault();
	e.stopPropagation();
});

//Sign in - Layover
accountFormSignin.on('submit', function(e) {

	systemShowLoader( $('#signinForm .system-loader') );
	$('#signinForm .account-submit').prop("disabled", true);
	//var path = $('#signinForm input[name=premium-article-path-signin]').val();
	var email = $('#signinForm input[name=email_signin]').val();
	var password = $('#signinForm input[name=password_signin]').val();
	var redirectlink = window.location.href;

	//Use JQuery AJAX request to post data to a Sling Servlet
	$.ajax({
		    type: "POST",
		    url: "/bin/schwarzkopf/ecrm/login",
		    data: { email: email, password: password , redirectlink:redirectlink},
		    success: function(data) {
			        if (data.login=="success") {
				systemHideLoader();
				localStorage.setItem('loginuser', data.loginuser);
				localStorage.setItem('optInNewsletter', data.optInNewsletter);
				localStorage.setItem('optInProductsTests', data.optInProductsTests);
				// data.redirect contains the string URL to redirect to
				location.reload();
			} else {
				// alert(data.textStatus);
				systemHideLoader();
				systemShowMessage(data.textStatus, 'red', $('#signinForm .system-message'));
				$('#signinForm .account-submit').prop("disabled", false);
			}
			    }
	});

	e.preventDefault();
	e.stopPropagation();
});

//Sign in - Article
accountFormSigninArticle.on('submit', function(e) {

	systemShowLoader( $('#signinForm-article .system-loader') );
	$('#signinForm-article .account-submit').prop("disabled", true);
	//var path = $('#signinForm-article input[name=premium-article-path-signin]').val();
	var email = $('#signinForm-article input[name=email_signin-article]').val();
	var password = $('#signinForm-article input[name=password_signin-article]').val();
	var redirectlink = window.location.href;

	//Use JQuery AJAX request to post data to a Sling Servlet
	$.ajax({
		    type: "POST",
		    url: "/bin/schwarzkopf/ecrm/login",
		    data: {  email: email, password: password, redirectlink:redirectlink },
		    success: function(data) {
			if (data.login=="success") {
				systemHideLoader();
				localStorage.setItem('loginuser', data.loginuser);
				localStorage.setItem('optInNewsletter', data.optInNewsletter);
				localStorage.setItem('optInProductsTests', data.optInProductsTests);
				// data.redirect contains the string URL to redirect to
				location.reload();
			} else {
				// alert(data.textStatus);
				systemHideLoader();
				systemShowMessage(data.textStatus, 'red', $('#signinForm-article .system-message'));
				$('#signinForm-article .account-submit').prop("disabled", false);
			}
		}
	});

	e.preventDefault();
	e.stopPropagation();
});


//Account Password Reset First call to MC(Salesforce) to get the password reset mail.
function accountFormPasswordEmail() {
	systemShowLoader( $('#accountPasswordForm .system-loader') );
	$('#accountPasswordForm .account-submit').prop("disabled", true);
	var path = $('#accountPasswordForm input[name=confirm-password-reset-form-page]').val();
	var email = $('#accountPasswordForm input[name=email]').val();
	//Use JQuery AJAX request to post data to a Sling Servlet
	$.ajax({
		    type: "POST",
		    url: "/bin/schwarzkopf/ecrm/operations",
		    data: { requestLink: location.protocol+'//'+location.hostname+path+".html?email="+email, email: email , forgotpasswordemail:"true"},
		    success: function(data) {
			if(data.checkInbox=="check email") {
				systemHideLoader();
				systemShowMessage(data.textStatus, 'green', $('#accountPasswordForm .system-message'));
			}else{
				systemShowMessage(data.textStatus, 'red', $('#accountPasswordForm .system-message'));
			}
			// alert(data.textStatus);
			$('#accountPasswordForm .account-submit').prop("disabled", true);
			window.location.href = "/content/schwarzkopf/de/de/home.html";
		}
	});
}

//Account Password Reset Second call to MC(Salesforce) to set the new password.
function accountFormPasswordConfirm() {
	systemShowLoader( $('#accountPasswordFormConfirm .system-loader') );
	$('#accountPasswordFormConfirm .account-submit').prop("disabled", true);
	var queryStrEmail = getParameterByName("email",window.location.href);
	//var email = $('#accountPasswordFormConfirm input[name=email]').val(queryStrEmail);
	var password = $('#accountPasswordFormConfirm input[name=password]').val();
	//Use JQuery AJAX request to post data to a Sling Servlet
	validatePassword();

	if(validation == 'true') {
		//Use JQuery AJAX request to post data to a Sling Servlet

		if(queryStrEmail != undefined && password != undefined){

			$.ajax({
				    type: "POST",
				    url: "/bin/schwarzkopf/ecrm/operations",
				    data: { email: queryStrEmail , password:password , forgotpassword:"true"},
				    success: function(data) {
					if(data.password=="reset"){
						systemHideLoader();
						$('#accountPasswordForm .account-submit').prop("disabled", true);
						systemShowMessage(data.textStatus, 'green', $('#accountPasswordFormConfirm .system-message'));
						// alert(data.textStatus);
						window.location.href = "/content/schwarzkopf/de/de/home.html";

					}else{
						systemHideLoader();
						systemShowMessage(data.textStatus, 'red', $('#accountPasswordFormConfirm .system-message'));
						// alert(data.textStatus);
					}
				}
			});


		}else{
			systemHideLoader();
			systemShowMessage('Irgendwas stimmt nicht! Bitte klicken Sie erneut auf den E-Mail-Link, um das Passwort zurückzusetzen.', 'red', $('#accountPasswordFormConfirm .system-loader'));
		}
	} else {
		systemHideLoader();
		systemShowMessage('Passwords don\'t match', 'red', $('#accountPasswordFormConfirm .system-message'));
	}
}

//END 


signinLink.on('click', function (e) {
	e.preventDefault();
	e.stopPropagation();
	toggleAccount();
}); 
signupLink.on('click', function (e) {
	e.preventDefault();
	e.stopPropagation();
	toggleAccount();
	toggleAccountForm();
});

accountToggleFormSignin.on('click', function(e) {
	e.preventDefault();
	e.stopPropagation();
	toggleAccountForm('signin');
});

accountToggleFormSignup.on('click', function(e) {
	e.preventDefault();
	e.stopPropagation();
	toggleAccountForm('signup');
});

accountToggleFormConfirm.on('click', function(e) {
	e.preventDefault();
	e.stopPropagation();
	toggleAccountForm('confirm');
});


function toggleAccount() {
	if (accountLayer.hasClass('is-inactive')) {
		accountLayer.removeClass('is-inactive').addClass('is-active');
		body.addClass('account-active');
		$('html').addClass('noscroll');
	} else {
		accountLayer.removeClass('is-active').addClass('is-inactive');
		body.removeClass('account-active');
		$('html').removeClass('noscroll');

	}
}

function closeLayover() {
	accountLayer.removeClass('is-active').addClass('is-inactive');
	body.removeClass('account-active');
	$('html').removeClass('noscroll');
}

function openLayover(){
	accountLayer.removeClass('is-inactive').addClass('is-active');
	body.addClass('account-active');
	$('html').addClass('noscroll');
}

function toggleAccountForm(target) {
	if(target=='signin') {
		accountSignin.removeClass('is-inactive').addClass('is-active');
		accountSignup.removeClass('is-active').addClass('is-inactive');
		accountSignupconfirm.removeClass('is-active').addClass('is-inactive');
	} else if (target=='signup') {
		accountSignin.removeClass('is-active').addClass('is-inactive');
		accountSignup.removeClass('is-inactive').addClass('is-active');
		accountSignupconfirm.removeClass('is-active').addClass('is-inactive');
	} else if (target=='confirm') {
		accountSignupconfirm.removeClass('is-inactive').addClass('is-active');
		accountSignup.removeClass('is-active').addClass('is-inactive');
		accountSignin.removeClass('is-active').addClass('is-inactive');
	}
}

$(document).keyup(function(e) {
	if (e.keyCode === 27) { 
		closeLayover();
	}
});

var privacypolicy = document.getElementById("privacypolicy");
if (privacypolicy) {
	privacypolicy.setCustomValidity("Please indicate that you have read and agree the Privacy Policy");
} 


function getQueryVariable(variable)
{
	var query = window.location.search.substring(1);
	var vars = query.split("&");
	for (var i=0;i<vars.length;i++) {
		var pair = vars[i].split("=");
		if(pair[0] == variable){return pair[1];}
	}
	return(false);
}
if (accountPasswordReset[0]) {
	$('#email').val(getQueryVariable(email));

}
var password = $("#password")[0];
var confirm_password = $("#confirm_password")[0];
var validation = 'false';
function validatePassword() {
	password = $("#password")[0];
	confirm_password = $("#confirm_password")[0];
	if(password.value != confirm_password.value) {
		validation = 'false';
	} else {
		validation = 'true';
	}
}
accountPassword.on('change', function() {
	validatePassword();
});
accountPasswordConfirm.on('change', function() {
	validatePassword();
});
accountPasswordConfirm.keyup(function() {
	validatePassword();
});

function getCookie(c_name) {
	var c_value = document.cookie,
	c_start = c_value.indexOf(" " + c_name + "=");
	if (c_start == -1) c_start = c_value.indexOf(c_name + "=");
	if (c_start == -1) {
		c_value = null;
	} else {
		c_start = c_value.indexOf("=", c_start) + 1;
		var c_end = c_value.indexOf(";", c_start);
		if (c_end == -1) {
			c_end = c_value.length;
		}
		c_value = unescape(c_value.substring(c_start, c_end));
	}
	return c_value;
}


//function deleteCookie (name,path,domain) {
//domain = window.location.hostname;
//if (getCookie(name)) {
//document.cookie = name + "=" +
//((path) ? "; path=" + path : "") +
//((domain) ? "; domain=" + domain : "") +
//"; expires=Thu, 01-Jan-70 00:00:01 GMT";
//}
//}
function deleteCookie (name,path,domain) {
	$.ajax({
		    type: "GET",
		    url: "/bin/schwarzkopf/ecrm/logout",
		    success: function(data) {
			        if (data=="Logout Successful") {
				localStorage.removeItem('loginuser');
				localStorage.removeItem('optInNewsletter');
				localStorage.removeItem('optInProductsTests');
				//temporary redirection
				window.location.href = "/content/schwarzkopf/de/de/home.html";
				    }
			    }
	});
}

function getParameterByName(name, url) {
	if (!url) url = window.location.href;
	name = name.replace(/[\[\]]/g, '\\$&');
	var regex = new RegExp('[?&]' + name + '(=([^&#]*)|&|#|$)'),
	results = regex.exec(url);
	if (!results) return null;
	if (!results[2]) return '';
	return decodeURIComponent(results[2]);
}

function logout() {
	var domain = window.location.hostname;
	deleteCookie("ecrm_login_token","/",domain);

}
//END ACC FUNCTIONS
accountLogoutClose.on('click', function(e) {
	e.preventDefault();
	e.stopPropagation();
	closeLogoutMessage();
});
function closeLogoutMessage() {
	accountConfirmLogout.removeClass('is-active').addClass('is-inactive'); 
	body.removeClass('account-active');
	$('html').removeClass('noscroll');
}

function openLogoutMessage(){
	accountConfirmLogout.removeClass('is-inactive').addClass('is-active');
	body.addClass('account-active');
	$('html').addClass('noscroll');
}

$( document ).ready(function() {
//	Do something when cookie is available
	if (crm_cookie) { 
		accountIcon.addClass('account-icon--active').removeClass('account-icon--inactive');
		var email = decodeURIComponent(localStorage.getItem('loginuser'));
        var newsLetterCheck = (localStorage.getItem('optInNewsletter')== "True") ? true : false ;
        var productTestCheck = (localStorage.getItem('optInProductsTests')== "True") ? true : false ;
        $('#newsLetterCheckbox').prop("checked", newsLetterCheck);
        $('#productTestCheckbox').prop("checked", productTestCheck);
		$('.account__form-account-details #email_account_profile').html(email);
		articlePremiumLayer.removeClass('logged-out');
	} else {
		accountIcon.addClass('account-icon--inactive').removeClass('account-icon--active');
		// Hide content of premium article
		articlePremium.addClass('logged-out');  
		articlePremiumLayer.addClass('logged-out');
	} 


});

function systemShowMessage(message, color, el) {
	if (el) {
		el.html(message);
	} else { 
		systemMessage.html(message);
	}
	systemMessage.css("color", color);
}

function systemHideMessage() {
	systemMessage.html("");
	systemMessage.css("color", "#000");
}

function systemShowLoader(el) {

	if (el) {
		el.removeClass('inactive');
	} else {
		systemLoader.removeClass('inactive');
	}

}
function systemHideLoader(el) {

	systemLoader.addClass('inactive');
}

//Delete Contact
function deleteContact(){
	var crm_cookie = getCookie("ecrm_login_token");
	var email_user = decodeURIComponent(localStorage.getItem('loginuser'));
	if(crm_cookie && email_user!=undefined){
		$.ajax({
			    type: "POST",
			    url: "/bin/schwarzkopf/ecrm/operations",
			    data: { email: email_user,deletecontact:"true"},
			    success: function(data) {
				alert("Ihr Konto wurde gelöscht. Sie werden jetzt abgemeldet.")
				logout();
			}
		});
	}


}



//On click handler for product form slider : select product
$('.product-form .product-card').on('click', function(e) {

	// Select element
	var productid = $(this)[0].dataset.slickIndex;
	var productname = $(this)[0].dataset.title;
	// Set input field
	$('.product-form form #selectedProduct').val(productname);
	// Set indicator to productslider element
	$('.product-form .product-card').removeClass('is-active'); // remove all active states
	$('*[data-slick-index="'+ productid + '"]').addClass('is-active'); // add active state to clicked element

});


//Submit the form and make an Ajax call
$('.product-form form').on('submit', function(e) {

	systemShowLoader();
	// Get variables 
	var selectedproduct = $('#selectedProduct')[0].value;
	var crm_cookie = getCookie("ecrm_login_token");
	var email_user = decodeURIComponent(localStorage.getItem('loginuser'));
	var campaignid= $('.product-form form input[name=campaignid]').val();
	var firstname = decodeURIComponent($('.product-form form input[name=firstname]').val());
	var lastname= decodeURIComponent($('.product-form form input[name=lastname]').val());
	var street= decodeURIComponent($('.product-form form input[name=street]').val());
	var housenumber= decodeURIComponent($('.product-form form input[name=housenumber]').val());
	var zipcode= decodeURIComponent($('.product-form form input[name=zipcode]').val());
	var city= decodeURIComponent($('.product-form form input[name=city]').val());
	var country= decodeURIComponent($(".product-form #country").val());
	var requestlink = window.location.href;
	var partner=getValues["partner"];
	if(partner == undefined){
		partner="";
	}

	// Validate if productname is set
	if (selectedproduct ) {
		// Call API to send data
		if(crm_cookie && email_user!=undefined){
			$.ajax({
				    type: "POST",
				    url: "/bin/schwarzkopf/ecrm/operations",
				    data: { email: email_user,firstname:firstname,lastname:lastname,street:street,housenumber:housenumber,zipcode:zipcode,city:city,country:country,selectedproduct:selectedproduct,requestlink:requestlink,campaignid:campaignid,update:"true",partner:partner},
				    success: function(data) {
					systemHideLoader();
					$('.product-form form product-from-submit').prop("disabled", true);
					if(data.redirect){
						// alert(data.textStatus);
						window.location.href = data.redirect;
					}else if(data.error ==""){
						systemShowMessage(data.textStatus, 'red', $('.product-form .system-message'));
					}
				}
			});
		}else{
			systemHideLoader();
			systemShowMessage('Bitte loggen Sie sich ein, um an dem Produkttest teilzunehmen.', 'red', $('.product-form .system-message'));
		}
	} else {
		systemHideLoader();
		systemShowMessage('Bitte wählen Sie ein Produkt aus!', 'red', $('.product-form .system-message'));
	}
	e.preventDefault();  
	e.stopPropagation();
});


$('#saveAccountPreferences').on('click', function(e) {
	var newsLetterCheckbox = $('#newsLetterCheckbox').prop("checked")==true?"True":"False";
	var productTestCheckbox = $('#productTestCheckbox').prop("checked")==true?"True":"False";
	var user_email = window.btoa(decodeURIComponent(localStorage.getItem('loginuser')));
	$('#subscribeForm .account-submit').prop("disabled", true);
	/*$.ajax({
		    type: "POST",
        	contentType: "application/json; charset=utf-8",
        	crossDomain: true,
    		dataType: 'jsonp',
			contentType: "application/json; charset=utf-8",
		    url: "http://cloud.news.schwarzkopf.de/unsubs",
		 	data: { p1: user_email, p2: newsLetterCheckbox, p3: productTestCheckbox },
		    success: function(data) {
				alert(data);
				systemHideLoader();
				newsLetterCheckbox==true ? localStorage.setItem('optInNewsletter','True') : localStorage.setItem('optInNewsletter','False'); 
				productTestCheckbox==true? localStorage.setItem('optInProductsTests','True') : localStorage.setItem('optInProductsTests','False'); 
				systemShowMessage("Ihre E-Mail-Einstellungen werden aktualisiert", 'green', $('#subscribeForm .system-message') ); 

		}
	});*/
	var url = "http://cloud.news.schwarzkopf.de/unsubs?p1="+user_email+"&p2="+newsLetterCheckbox+"&p3="+productTestCheckbox;
	systemShowMessage("Ihre E-Mail-Einstellungen werden aktualisiert", 'green', $('#subscribeForm .system-message') );
	localStorage.setItem('optInNewsletter',newsLetterCheckbox); 
	localStorage.setItem('optInProductsTests',productTestCheckbox);     
	//opens window and closes in 2 seconds to make a call to MC.
	var wnd = window.open(url ,'targetWindow','toolbar=no,location=no,status=no,menubar=no,scrollbars=no,resizable=no,width=50px,height=50px');
	setTimeout(function() {
		wnd.close();
	}, 2000);
	e.preventDefault();  
	e.stopPropagation();
});