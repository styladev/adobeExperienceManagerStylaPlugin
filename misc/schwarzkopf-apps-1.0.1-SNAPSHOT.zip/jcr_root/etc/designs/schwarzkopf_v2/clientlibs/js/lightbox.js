const lightbox = function() {
    const $html = document.querySelector('html');
    const $body = document.querySelector('body');
    const $stage = document.querySelector('.stage');
    const $lightboxWrapper = document.querySelector('.lightbox');
    const $lightboxHeader = document.querySelector('.lightbox__header');

    const triggerSelector = 'a[href*="choicify.net"]';
    const triggerSelectors = '.stage__thumbs h3 ' + triggerSelector +
        ', .stage__img-wrapper ' + triggerSelector + ', .stage__body h2 ' + triggerSelector;

    if (!$stage || !$lightboxWrapper) {
        return;
    }

    const $lightboxTriggers = $stage.querySelectorAll(triggerSelectors);
    const $lightboxClose = $lightboxWrapper.querySelector('.lightbox__close');
    const $lightboxContent = $lightboxWrapper.querySelector('.lightbox__content');

    for (let i = 0; i < $lightboxTriggers.length; i++) {
        $lightboxTriggers[i].addEventListener('click', handleClick);
    }

    $lightboxClose.addEventListener('click', function(e) {
    	e.preventDefault();
    	e.stopPropagation();
    	closeLightbox();
    });

    $lightboxHeader.addEventListener('click', function(e) {
    	e.preventDefault();
    	e.stopPropagation();
    	closeLightbox();
    });

    document.addEventListener('keydown', function(e) {
        if (e.keyCode === 27) {
       		closeLightbox();
       	}
    }, false);

    function handleClick(e) {
        e.preventDefault();
       	e.stopPropagation();

       	const url = e.currentTarget.getAttribute('href') || 'https://choicify.net';

        if ($lightboxContent.querySelector('.lightbox__iframe') === null) {
            createIframe(url);
        }

       	openLightbox();
    }

    function openLightbox() {
        if ($body.offsetWidth < 769) {
            window.scrollTo(0,0);
            $body.classList.add('lightbox--open');
            $lightboxHeader.classList.add('lightbox__header--isActive');
        }

        $lightboxWrapper.classList.add('lightbox--isActive');
        $html.classList.add('noscroll');
    }

    function closeLightbox() {
        $body.classList.remove('lightbox--open');
        $lightboxWrapper.classList.remove('lightbox--isActive');
        $html.classList.remove('noscroll');
        $lightboxHeader.classList.remove('lightbox__header--isActive');
    }

    function createIframe(src) {
        const $iframe = document.createElement('iframe');
        $iframe.onload = function() {
            $lightboxWrapper.classList.add('lightbox--isLoaded');
        };
        $iframe.src = src + '?isiframe=true';
        $iframe.setAttribute('allow', 'geolocation; microphone; camera');
        $iframe.className = 'lightbox__iframe';

        $lightboxContent.appendChild($iframe);
    }
};

$(document).ready(function() {
    lightbox();
});
