/*
 * tracking - only enabled if cookie policy is accepted
 */

"use strict";

var gaSiteId;
var gtmId;

/**
 * Auxillary method for older browsers.
 *
 * @param {type} className CSS class name
 * @returns {NodeList}
 */
var getElementsByClassName = function (className) {
    if (document.getElementsByClassName) {
        return document.getElementsByClassName(className);
    } else {
        return document.querySelectorAll('.' + className);
    }
};

/*
 * Tracking will be started, if the cookie disclaimer is disabled
 * or if it is enabled and the cookie policy has been accepted
 */
var trackingAccepted = function () {
    var result = ((typeof isCookiePolicyDisclaimerAvailable === 'undefined') ||
            !isCookiePolicyDisclaimerAvailable() ||
            isCookiePolicyAccepted()) && (typeof isDoNotTrackCookieSet === 'undefined' || !isDoNotTrackCookieSet());
    return result;
};

/**
 * Enable Google Analytics.
 * @returns {undefined}
 */
var enableGA = function () {
    if (typeof gaSiteId !== 'undefined') {
        (function () {
            var _gaLoader = document.createElement('script');
            _gaLoader.type = 'text/javascript';
            _gaLoader.async = true;
            _gaLoader.src = ('https:' === document.location.protocol ? 'https://' : 'http://') + 'stats.g.doubleclick.net/dc.js';
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(_gaLoader, s);
        })();
        window.setTimeout("_gaq.push(['_trackEvent', 'NoBounce', 'Over 30 seconds'])", 30000);
    }
};

/**
 * Enable Google Tag Manager
 * @returns {undefined}
 */
var enableGTM = function () {
    if (typeof gtmId !== 'undefined') {
        (function (w, d, s, l, i) {
            w[l] = w[l] || [];
            w[l].push({
                'gtm.start': new Date().getTime(), event: 'gtm.js'
            });
            var f = d.getElementsByTagName(s)[0], j = d.createElement(s), dl = l !== 'dataLayer' ? '&l=' + l : '';
            j.async = true;
            j.src = '//www.googletagmanager.com/gtm.js?id=' + i + dl;
            f.parentNode.insertBefore(j, f);
        })(window, document, 'script', 'dataLayer', gtmId);
    }

    /*
     * Mark trackable click events (jQuery required)
     */
    (function (enabled) {

        if (!enabled) {
            return;
        }

        $("[data-layer]").each(function (i, item) {
            $(item).click(function () {

                dataLayer.push({
                    'event': 'x000StandardEvent',
                    'category': $(item).data("layer-category"),
                    'action': $(item).data("layer-action"),
                    'label': $(item).data("layer-label"),
                    'value': i
                });

            });
        });

    })(typeof jQuery !== 'undefined');
};

var startTracker = function () {
    if (trackingAccepted()) {
        enableGTM();
        enableGA();
    }
};

startTracker();
