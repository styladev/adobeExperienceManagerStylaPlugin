;
(function(CQ) {

    new CQ.data.SlingStore({
        autoLoad: true,
        url: CQ.WCM.getPagePath() + "/jcr:content.json"
    }).load({
        callback: function(records, options, success) {
            if (success) {
                if (records.length) {
                    var template = records[0].get('cq:template');

                    if (typeof (template) !== 'undefined') {
                        if (template.match(/.*content\/feed$/)) {
                            CQ.wcm.Sidekick.DEFAULT_ACTIONS.splice(1,0,{
                                "text": CQ.I18n.getMessage("el_push_feed_label"),
                                "context": CQ.wcm.Sidekick.PAGE,
                                "handler": function() {

                                    var path = this.path;

                                    // "this" is handler for sidekick
                                    CQ.Ext.MessageBox.confirm(
                                            CQ.I18n.getMessage("el_push_feed_label"),
                                            CQ.I18n.getMessage("el_push_feed_message"),
                                            function(btn) {
                                                if (btn === 'yes') {
                                                    /*
                                                     * TODO: Implement servlet call
                                                     */
                                                    CQ.Ext.MessageBox.alert(
                                                            CQ.I18n.getMessage("Error"), 
                                                            "This function is not yet implemented"
                                                    );
                                                }
                                            }
                                    );
                                }
                            });
                        }
                    }

                }
            }
        }
    });

})(CQ);