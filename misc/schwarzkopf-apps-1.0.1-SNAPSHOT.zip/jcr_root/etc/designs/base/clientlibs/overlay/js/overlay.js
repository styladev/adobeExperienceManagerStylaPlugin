var generalcookiename = "overlay";

var openOverlay = function (id, source) {

    if (id === null) {
        id = $(source).closest(".overlay").attr('id');
    }

    if (typeof source === 'undefined') {
        source = $("#" + id);
    }

    $.cookie(generalcookiename + '-' + id, "1", {
        "expires": 365,
        "path": "/"
    });
    $.cookie(generalcookiename, "1", {
        "expires": 1,
        "path": "/"
    });

    $(source).addClass("ifoverlayed");
    $('body').addClass("overlayed");

    $(source).css({
        "position": "relative",
        "top": Math.max(0, $(window).innerHeight() - $(source).outerHeight()) / 2
    });

    $(".overlays")
            .unbind('click')
            .click(function() {
                closeOverlay(id, source);
            });
            
};

var closeOverlay = function (id, source) {

    if (id === null) {
        id = $(source).closest(".overlay").attr('id');
    }

    if (typeof source === 'undefined') {
        source = $("#" + id);
    }

    $(source).removeClass("ifoverlayed");
    $("body").removeClass("overlayed");

};

$(document).ready(function () {

    $(".overlays .overlay").each(function () {
        var id = $(this).attr("id");
        var cookiename = generalcookiename + "-" + id;

        if (!($.cookie(cookiename) || $.cookie(generalcookiename))) {
            var me = $(this);
            var validFrom = parseInt(me.data("validFrom"));
            var validTo = parseInt(me.data("validTo"));

            if ((validFrom === "" || new Date() > new Date(validFrom) &&
                    (validTo === "" || new Date(validTo)) > new Date())) {
                openOverlay(id, $(this));
            }
            
        }
        
    });
    

});
